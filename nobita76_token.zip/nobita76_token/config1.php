<?php
#Xem hướng dẫn tại : https://www.youtube.com/watch?v=VQQX6kAELb4
$dataLog  =  array(
'email' => 'toilaphap@hotmail.com',
'pass' => 'dangcap1',
'apps' =>'41158896424',# ID Applikasi nya
);

?>