<?php
#Xem hướng dẫn tại : https://www.youtube.com/watch?v=VQQX6kAELb4
$domain= 'http://phap.blogmuaxuan.com'; // không có / ở cuối
$linktoken= 'http://phap.blogmuaxuan.com/nobita76_token/token.txt'; // nên để trong file txt nhé
$id_like= '100008721971200'; // ID User VIP
$limitlike= '100000'; // Số Lượng Like/Status
?>